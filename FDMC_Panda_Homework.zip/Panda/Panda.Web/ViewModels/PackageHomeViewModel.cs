﻿namespace Panda.Web.ViewModels
{
    public class PackageHomeViewModel
    {
        public string Id { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
    }
}

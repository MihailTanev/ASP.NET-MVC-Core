﻿namespace FDMC.Web.ViewModels.Cat
{
    public class AddCatViewModel
    {
        public string Name { get; set; }

        public int Age { get; set; }

        public string Breed { get; set; }

        public string ImageUrl { get; set; }
    }
}

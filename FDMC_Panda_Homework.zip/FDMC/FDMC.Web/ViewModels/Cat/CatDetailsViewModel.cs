﻿namespace FDMC.Web.ViewModels.Cat
{
    public class CatDetailsViewModel
    {
        public int Id { get; set; }

        public string CatName { get; set; }

        public int CatAge { get; set; }

        public string CatBreed { get; set; }

        public string CatImageUrl { get; set; }
    }
}

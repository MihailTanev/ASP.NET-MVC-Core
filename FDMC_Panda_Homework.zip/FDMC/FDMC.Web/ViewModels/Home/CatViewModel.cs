﻿namespace FDMC.Web.ViewModels.Home
{
    public class CatViewModel
    {
        public int Id { get; set; }
        public string CatName { get; set; }
    }
}
